export interface Movie {
    title: string;
    releaseYear: number;
  }
  