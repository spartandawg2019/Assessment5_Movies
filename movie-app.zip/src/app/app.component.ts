import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router'; // Ensure RouterOutlet is properly imported
import { MovieListComponent } from './movie-list/movie-list.component'; // Import MovieListComponent

@Component({
  selector: 'app-root',
  standalone: true, // This is required for standalone components
  imports: [RouterOutlet, MovieListComponent], // Add MovieListComponent here
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'] // Fix incorrect "styleUrl" property
})
export class AppComponent {
  title = 'movie-app';
}